# SimpleSAMLphp Translation

TODO: please complete this doc on how to translate SimpleSAMLphp
