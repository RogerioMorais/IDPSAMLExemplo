# Upgrade notes for SimpleSAMLphp 1.11

* Support for the Holder-of-Key profile in the SAML 2.0 SP has been disabled by default.
  To enable it, set `saml20.hok.assertion` to `TRUE` in `config/authsources.php`.
