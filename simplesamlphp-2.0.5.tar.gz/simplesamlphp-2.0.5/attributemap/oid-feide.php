<?php

$attributemap = [
    'urn:oid:0.9.2342.19200300.100.1.41' => 'mobile',
    'urn:oid:1.3.6.1.4.1.5923.1.1.1.6'   => 'eduPersonPrincipalName',
    'urn:oid:0.9.2342.19200300.100.1.3'  => 'mail',
    'urn:oid:2.5.4.3'                    => 'cn',
    'urn:oid:2.16.840.1.113730.3.1.241'  => 'displayName',
    'urn:oid:2.5.4.4'                    => 'sn',
    'urn:oid:2.5.4.42'                   => 'givenName',
    'urn:oid:2.16.756.1.2.5.1.1.1'       => 'eduPerson',
];
